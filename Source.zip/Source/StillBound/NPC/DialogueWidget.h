// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "DialogueData.h"
#include "DialogueOptionButton.h"
#include "DialogueWidget.generated.h"

/**
 * 
 */

class UImage;
class UTextBlock;
class UVerticalBox;
class UBotton;
class UDialogueComponent;
class UDialogueOptionButton;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDialogueOptionSelected, int32, OptionIndex);

UCLASS()
class STILLBOUND_API UDialogueWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	//��ȭ ������ ǥ��
	UFUNCTION(BlueprintCallable, Category = "Dialogue")
	void ShowDialogue(const FDialogueRow& DialogueData);

	UFUNCTION(BlueprintImplementableEvent, Category = "Dialogue")
	void OnMenuTypeChanged(EMenuType NewMenuType);

	//��ȭ �ޱ�
	UFUNCTION(BlueprintCallable, Category = "Dialogue")
	void CloseDialogue();

	//������ Ŭ�� �̺�
	UFUNCTION(BlueprintCallable, Category = "Dialogue")
	void HandleOptionSelected(int32 OptionIndex);

	UPROPERTY(BlueprintAssignable, Category = "Events")
	FOnDialogueOptionSelected OnOptionClicked;

	//��ȭ ������Ʈ ����
	UFUNCTION(BlueprintCallable, Category = "Dialogue")
	void SetDialogueComponent(UDialogueComponent* Component);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSubclassOf<class UUserWidget> OptionButtonClass;

	//���ε� ���� ������

	UPROPERTY(meta = (BindWidget))
	class UImage* IMG_Profile;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* TXT_NPCName;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* TXT_DialogueContent;

	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* VB_OptionList;

protected:
	virtual void NativeConstruct() override;

	UPROPERTY(BlueprintReadOnly, Category = "Dialogue")
	UDialogueComponent* DialogueComponent = nullptr;

	UPROPERTY(BlueprintReadOnly, Category = "Dialogue")
	FDialogueRow CurrentDialogueData;

	UPROPERTY(meta = (BindWidget))
	UTextBlock* TXT_MenuTitle;

private:
	UPROPERTY()
	TArray<UDialogueOptionButton*> OptionButtonPool;
};

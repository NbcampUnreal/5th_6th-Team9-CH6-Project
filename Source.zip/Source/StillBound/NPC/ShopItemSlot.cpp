#include "ShopItemSlot.h"
#include "NPC/NPCCharacter.h"
#include "Data/ItemData.h"
#include "Items/ItemBase.h"
#include "UI/Inventory/InventoryTooltip.h"
#include "UI/Inventory/InventoryItemSlot.h" 
#include "ShopWidget.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Components/Button.h"

void UShopItemSlot::NativeConstruct()
{
    Super::NativeConstruct();

    // �ʱ�ȭ
    CachedItemData = nullptr;
    CachedPrice = 0;
    ShopItemTooltip = nullptr;

    // ��ư ���ε�
    if (BTN_Buy)
    {
        //BTN_Buy->OnClicked.AddDynamic(this, &UShopItemSlot::OnBuyButtonClicked);
        BTN_Buy->OnClicked.AddUniqueDynamic(this, &UShopItemSlot::OnBuyButtonClicked);
    }
}

void UShopItemSlot::NativeOnMouseEnter(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
    Super::NativeOnMouseEnter(InGeometry, InMouseEvent);

    if (!TooltipClass || !NPCRef) return;

    // ĳ�õ� �����Ͱ� ������ ����
    if (!CachedItemData)
    {
        UE_LOG(LogTemp, Warning, TEXT("[ShopItemSlot] No cached item data for tooltip"));
        return;
    }

    // ============================================
    // Tooltip ����
    // ============================================
    if (!ShopItemTooltip)
    {
        ShopItemTooltip = CreateWidget<UInventoryTooltip>(this, TooltipClass);
        if (!ShopItemTooltip)
        {
            UE_LOG(LogTemp, Error, TEXT("[ShopItemSlot] Failed to create tooltip!"));
            return;
        }
    }
    // ============================================
    // �ӽ� InventoryItemSlot ���� (RefreshFromSlot�� �ʿ�)
    // ============================================
    UInventoryItemSlot* TempSlot = NewObject<UInventoryItemSlot>(this);
    if (!TempSlot)
    {
        UE_LOG(LogTemp, Error, TEXT("[ShopItemSlot] Failed to create temp slot!"));
        return;
    }
    // ============================================
    // �ӽ� ItemBase ���� (InventoryTooltip�� ItemBase�� ����)
    // ============================================
    UItemBase* TempItem = NewObject<UItemBase>(this);
    if (!TempItem)
    {
        UE_LOG(LogTemp, Error, TEXT("[ShopItemSlot] Failed to create temp item!"));
        return;
    }

    // ItemBase�� ������ ����
    TempItem->ID = CachedItemData->ID;
    TempItem->ItemType = CachedItemData->ItemType;
    TempItem->ItemQuality = CachedItemData->ItemQuality;
    TempItem->NumericData = CachedItemData->NumericData;
    TempItem->TextData = CachedItemData->TextData;
    TempItem->AssetData = CachedItemData->AssetData;
    TempItem->ItemStatistics = CachedItemData->ItemStatistics;
    TempItem->SetQuantity(1);

    // ============================================
    // Tooltip ������Ʈ (���� ���� �߰�)
    // ============================================

    // TempSlot�� TempItem ����
    TempSlot->SetItemReference(TempItem);

    // ============================================
    // Tooltip�� Slot ���� �� RefreshFromSlot ȣ��
    // ============================================
    ShopItemTooltip->InventorySlotBeingHovered = TempSlot;
    ShopItemTooltip->RefreshFromSlot();


    // Viewport�� �߰�
    ShopItemTooltip->AddToViewport(999);

    UE_LOG(LogTemp, Log, TEXT("[ShopItemSlot] Tooltip shown: %s (%dG)"),
        *CachedItemData->TextData.Name.ToString(),
        CachedPrice);
}

void UShopItemSlot::NativeOnMouseLeave(const FPointerEvent& InMouseEvent)
{
    Super::NativeOnMouseLeave(InMouseEvent);

    // Tooltip ����
    if (ShopItemTooltip && ShopItemTooltip->IsInViewport())
    {
        ShopItemTooltip->RemoveFromParent();

        UE_LOG(LogTemp, Log, TEXT("[ShopItemSlot] Tooltip hidden"));
    }
}

void UShopItemSlot::SetShopItemData(const FShopItemData& InItemData, UShopWidget* InShopWidget, ANPCCharacter* InNPC)
{
    ItemData = InItemData;
    ShopWidget = InShopWidget;
    NPCRef = InNPC;

    if (!ShopWidget)
    {
        UE_LOG(LogTemp, Error, TEXT("[ShopItemSlot] ShopWidget is NULL!"));
        return;
    }
    if (!NPCRef)
    {
        UE_LOG(LogTemp, Error, TEXT("[ShopItemSlot] NPCRef is NULL!"));
        return;
    }

    // NPC���� ������ ������ ��������
    const FItemDataRow* FullItemData = NPCRef->GetItemData(ItemData.ItemRowName);
    if (!FullItemData)
    {
        UE_LOG(LogTemp, Error, TEXT("[ShopItemSlot] Item data not found: %s"),
            *ItemData.ItemRowName.ToString());

        // �⺻�� ǥ��
        if (TXT_ItemName)
        {
            TXT_ItemName->SetText(FText::FromString(TEXT("Unknown Item")));
        }
        if (TXT_ItemPrice)
        {
            TXT_ItemPrice->SetText(FText::FromString(TEXT("Price: 0G")));
        }
        return;
    }

    // ============================================
    // ������ ĳ�� (Tooltip���� ���)
    // ============================================
    CachedItemData = FullItemData;
    CachedPrice = FullItemData->ItemStatistics.SellValue;

    // ============================================
    // UI ������Ʈ
    // ============================================

    // ������ �̸�
    if (TXT_ItemName)
    {
        TXT_ItemName->SetText(FullItemData->TextData.Name);
    }

    // ���� ǥ��
    if (TXT_ItemPrice)
    {
        FText PriceText = FText::Format(
            FText::FromString(TEXT("{0}G")),
            FText::AsNumber(CachedPrice)
        );
        TXT_ItemPrice->SetText(PriceText);
    }
    //���
    if (TXT_ItemStock)
    {
        if (ItemData.CurrentStock < 0)
        {
            TXT_ItemStock->SetText(FText::FromString( TEXT("Infi_Stock")));
        }
        else
        {
            FText StockText = FText::Format(
                FText::FromString(TEXT("{0}G")),
                FText::AsNumber(ItemData.CurrentStock)
            );
            TXT_ItemStock->SetText(StockText);
        }
    }

    // ������
    if (IMG_ItemIcon && FullItemData->AssetData.Icon)
    {
        IMG_ItemIcon->SetBrushFromTexture(FullItemData->AssetData.Icon);
    }

    // ǰ�� ǥ��
    if (ItemData.CurrentStock <= 0)
    {
        // ��ư ��Ȱ��ȭ
        if (BTN_Buy)
        {
            BTN_Buy->SetIsEnabled(false);
        }

        // ������ �̸��� "(ǰ��)" �߰�
        if (TXT_ItemName)
        {
            FText OutOfStockText = FText::Format(
                FText::FromString(TEXT("{0} (Out Of Stock)")),
                FullItemData->TextData.Name
            );
            TXT_ItemName->SetText(OutOfStockText);
        }

        // ���� �ؽ�Ʈ ȸ������
        if (TXT_ItemPrice)
        {
            TXT_ItemPrice->SetColorAndOpacity(FLinearColor(0.4f, 0.4f, 0.4f, 1.0f));
        }
        if (TXT_ItemStock)
        {
            TXT_ItemStock->SetText(FText::FromString(TEXT("Out Of Stock")));
            TXT_ItemStock->SetColorAndOpacity(
                FSlateColor(FLinearColor(0.75f, 0.38f, 0.38f, 1.0f)));
        }
    }
}

void UShopItemSlot::OnBuyButtonClicked()
{
    // 1. �⺻ ��ȿ�� �˻�
    if (!ShopWidget || ItemData.ItemRowName == NAME_None)
    {
        return;
    }

    // 2. ǰ�� üũ (��Ȯ�� 0�� ���� ���ƾ� ���� ����� �� �� ����)
    if (ItemData.CurrentStock == 0)
    {
        UE_LOG(LogTemp, Warning, TEXT("[ShopItemSlot] Item out of stock!"));
        return;
    }

    // 3. �÷��̾� ��Ʈ�ѷ� �� Ű �Է� ����
    const UWorld* World = GetWorld();
    if (!World) return;

    APlayerController* PC = World->GetFirstPlayerController();
    if (!PC) return;

    bool bShiftPressed = PC->IsInputKeyDown(EKeys::LeftShift) ||
        PC->IsInputKeyDown(EKeys::RightShift);

    // 4. ���� ���� ���� ����
    int32 PurchaseQuantity = 1; // �⺻�� 1��

    if (bShiftPressed)
    {
        // ���� ���� �� �ִ� ���� ����
        const int32 MaxBundleSize = 5;

        if (ItemData.CurrentStock < 0)
        {
            // ���� ����� ���: �׳� 5�� �� ä���� ����
            PurchaseQuantity = MaxBundleSize;
        }
        else
        {
            // ���� ����� ���: ���� ����� 5�� �� ���� �� ����
            PurchaseQuantity = FMath::Min(ItemData.CurrentStock, MaxBundleSize);
        }

        UE_LOG(LogTemp, Log, TEXT("[ShopItemSlot] Shift+Click: Buying %d items"), PurchaseQuantity);
    }

    // 5. ���� ������ ���� ���� ��û
    ShopWidget->BuyItem(ItemData.ItemRowName, PurchaseQuantity);
} 
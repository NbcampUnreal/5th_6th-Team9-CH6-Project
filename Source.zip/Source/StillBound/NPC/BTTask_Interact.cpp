// Fill out your copyright notice in the Description page of Project Settings.


#include "NPC/BTTask_Interact.h"
#include "Interface/InteractionInterface.h"
#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "GameFramework/Pawn.h"

UBTTask_Interact::UBTTask_Interact()
{
    NodeName = "Interact";
    bNotifyTick = true;

    // Blackboard Key ���� ����
    InteractionTargetKey.AddObjectFilter(
        this,
        GET_MEMBER_NAME_CHECKED(UBTTask_Interact, InteractionTargetKey),
        AActor::StaticClass()
    );
}

EBTNodeResult::Type UBTTask_Interact::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
    // �ʱ�ȭ
    ElapsedTime = 0.0f;
    bInteractionStarted = false;
    CachedTargetActor = nullptr;
    CachedAIController = nullptr;
    CachedControlledPawn = nullptr;

    // AI Controller ��������
    CachedAIController = OwnerComp.GetAIOwner();
    if (!CachedAIController)
    {
        UE_LOG(LogTemp, Error, TEXT("BTTask_Interact: No AI Controller"));
        return EBTNodeResult::Failed;
    }

    // Controlled Pawn ��������
    CachedControlledPawn = CachedAIController->GetPawn();
    if (!CachedControlledPawn)
    {
        UE_LOG(LogTemp, Error, TEXT("BTTask_Interact: No Controlled Pawn"));
        return EBTNodeResult::Failed;
    }

    // Blackboard���� Target Actor ��������
    UBlackboardComponent* BlackboardComp = OwnerComp.GetBlackboardComponent();
    if (!BlackboardComp)
    {
        UE_LOG(LogTemp, Error, TEXT("BTTask_Interact: No Blackboard Component"));
        return EBTNodeResult::Failed;
    }

    CachedTargetActor = Cast<AActor>(BlackboardComp->GetValueAsObject(InteractionTargetKey.SelectedKeyName));
    if (!CachedTargetActor)
    {
        UE_LOG(LogTemp, Warning, TEXT("BTTask_Interact: No Target Actor in Blackboard"));
        return EBTNodeResult::Failed;
    }

    // IInteractionInterface ���� Ȯ��
    if (!CachedTargetActor->GetClass()->ImplementsInterface(UInteractionInterface::StaticClass()))
    {
        UE_LOG(LogTemp, Error, TEXT("BTTask_Interact: Target does not implement IInteractionInterface"));
        return EBTNodeResult::Failed;
    }

    // �Ÿ� üũ
    if (bCheckDistance)
    {
        float Distance = FVector::Dist(
            CachedControlledPawn->GetActorLocation(),
            CachedTargetActor->GetActorLocation()
        );

        float MaxDistance = IInteractionInterface::Execute_GetInteractionDistance(CachedTargetActor);
        if (MaxDistance <= 0.0f)
        {
            MaxDistance = 200.0f;  // �⺻��
        }

        if (Distance > MaxDistance)
        {
            UE_LOG(LogTemp, Warning, TEXT("BTTask_Interact: Target too far (%.1f > %.1f)"),
                Distance, MaxDistance);
            return EBTNodeResult::Failed;
        }
    }

    // Ÿ�� �ٶ󺸱�
    if (bLookAtTarget)
    {
        CachedAIController->SetFocus(CachedTargetActor, EAIFocusPriority::Gameplay);
    }

    // ��ȣ�ۿ� ����
    IInteractionInterface::Execute_Interact(CachedTargetActor, nullptr);

    bInteractionStarted = true;

    UE_LOG(LogTemp, Log, TEXT("BTTask_Interact: Interaction started with %s"),
        *CachedTargetActor->GetName());

    // ���� �ð��� 0�̸� ��� ���� (������ �ݱ�, ����ġ ��)
    if (InteractionDuration <= 0.0f)
    {
        if (bAutoEndInteraction)
        {
            IInteractionInterface::Execute_EndInteract(CachedTargetActor);
        }

        CleanupInteraction();
        return EBTNodeResult::Succeeded;
    }

    // Duration�� ������ TickTask���� ó�� (��ȭ�� ���⼭ ���� ����)
    return EBTNodeResult::InProgress;
}

void UBTTask_Interact::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
    Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

    // ��ȿ�� �˻�
    if (!ValidateInteraction(OwnerComp))
    {
        UE_LOG(LogTemp, Warning, TEXT("BTTask_Interact: Validation failed during tick"));
        CleanupInteraction();
        FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
        return;
    }

    // Ÿ�� �ٶ󺸱� (�ε巯�� ȸ��)
    if (bLookAtTarget && CachedControlledPawn && CachedTargetActor)
    {
        FVector Direction = CachedTargetActor->GetActorLocation() - CachedControlledPawn->GetActorLocation();
        Direction.Z = 0.0f;  // ���� ȸ����

        FRotator TargetRotation = Direction.Rotation();
        FRotator CurrentRotation = CachedControlledPawn->GetActorRotation();

        FRotator NewRotation = FMath::RInterpTo(
            CurrentRotation,
            FRotator(CurrentRotation.Pitch, TargetRotation.Yaw, CurrentRotation.Roll),
            DeltaSeconds,
            5.0f  // ȸ�� �ӵ�
        );

        CachedControlledPawn->SetActorRotation(NewRotation);
    }

    // ��� �ð� ������Ʈ
    ElapsedTime += DeltaSeconds;

    // ���� �ð� üũ
    if (ElapsedTime >= InteractionDuration)
    {
        // �ڵ� ����
        if (bAutoEndInteraction && CachedTargetActor)
        {
            IInteractionInterface::Execute_EndInteract(CachedTargetActor);
            UE_LOG(LogTemp, Log, TEXT("BTTask_Interact: Interaction ended (auto) after %.1fs"), ElapsedTime);
        }

        CleanupInteraction();
        FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
    }
}

bool UBTTask_Interact::ValidateInteraction(UBehaviorTreeComponent& OwnerComp)
{
    // Task�� ���۵��� �ʾ����� ����
    if (!bInteractionStarted)
    {
        return false;
    }

    // ĳ�̵� �������� ��ȿ���� Ȯ��
    if (!IsValid(CachedAIController) || !IsValid(CachedControlledPawn) || !IsValid(CachedTargetActor))
    {
        UE_LOG(LogTemp, Warning, TEXT("BTTask_Interact: Cached references became invalid"));
        return false;
    }

    // Target�� ������ IInteractionInterface�� �����ϴ��� Ȯ��
    if (!CachedTargetActor->GetClass()->ImplementsInterface(UInteractionInterface::StaticClass()))
    {
        UE_LOG(LogTemp, Warning, TEXT("BTTask_Interact: Target no longer implements IInteractionInterface"));
        return false;
    }

    return true;
}

void UBTTask_Interact::CleanupInteraction()
{
    // Focus ����
    if (bLookAtTarget && IsValid(CachedAIController))
    {
        CachedAIController->ClearFocus(EAIFocusPriority::Gameplay);
    }

    // ĳ�̵� ���� �ʱ�ȭ
    CachedTargetActor = nullptr;
    CachedAIController = nullptr;
    CachedControlledPawn = nullptr;

    bInteractionStarted = false;
    ElapsedTime = 0.0f;

    UE_LOG(LogTemp, Log, TEXT("BTTask_Interact: Cleanup completed"));
}
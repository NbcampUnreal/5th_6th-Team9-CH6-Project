// Fill out your copyright notice in the Description page of Project Settings.


#include "NPC/DialogueComponent.h"
#include "Quest/QuestComponent.h"
#include "NPC/NPCCharacter.h"
#include "NPC/NPCCharacter_Quest.h"
#include "Character/PlayerCharacter_SB.h"
#include "Engine/DataTable.h"

// Sets default values for this component's properties
UDialogueComponent::UDialogueComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

}
    

// Called when the game starts
void UDialogueComponent::BeginPlay()
{
	Super::BeginPlay();

	if (MainMenuDataTable)
	{
		FString TableName = MainMenuDataTable->GetName();
		UE_LOG(LogTemp, Error, TEXT("MainMenuDataTable Name: %s"), *TableName);

		//Row Name ��� ���
		TArray<FName> RowNames = MainMenuDataTable->GetRowNames();
		UE_LOG(LogTemp, Error, TEXT("Row Names in MainMenuDataTable:"));
		for (FName RowName : RowNames)
		{
			UE_LOG(LogTemp, Error, TEXT("  - '%s'"), *RowName.ToString());
		}
	}
	
}

bool UDialogueComponent::StartDialogue(AActor* Interactor)
{
	UE_LOG(LogTemp, Error, TEXT("========================================"));
	UE_LOG(LogTemp, Error, TEXT("StartDialogue CALLED"));

	if (!MainMenuDataTable)
	{
		UE_LOG(LogTemp, Error, TEXT("MainMenuDataTable is NULL!"));
		return false;
	}

	// ���� ��ü ���
	FString TablePath = MainMenuDataTable->GetPathName();
	UE_LOG(LogTemp, Error, TEXT("MainMenuDataTable FULL PATH: %s"), *TablePath);

	FString MainTableName = MainMenuDataTable->GetName();
	UE_LOG(LogTemp, Error, TEXT("MainMenuDataTable Name: %s"), *MainTableName);

	// ��� Row ��� (�ٽ�!)
	TArray<FName> RowNames = MainMenuDataTable->GetRowNames();
	UE_LOG(LogTemp, Error, TEXT("========== TOTAL ROWS IN TABLE: %d =========="), RowNames.Num());

	for (FName RowName : RowNames)
	{
		FDialogueRow* Row = MainMenuDataTable->FindRow<FDialogueRow>(RowName, TEXT("Debug"));
		if (Row)
		{
			UE_LOG(LogTemp, Error, TEXT(">>> Row Name: '%s'"), *RowName.ToString());
			UE_LOG(LogTemp, Error, TEXT("    DialogueID: %d"), Row->DialogueID);
			UE_LOG(LogTemp, Error, TEXT("    DialogueText: %s"), *Row->DialogueText.ToString());
			UE_LOG(LogTemp, Error, TEXT("    Options Count: %d"), Row->Options.Num());

			for (int32 i = 0; i < Row->Options.Num(); i++)
			{
				UE_LOG(LogTemp, Error, TEXT("      Option %d: %s (Switch:%d, NextID:%d)"),
					i,
					*Row->Options[i].OptionText.ToString(),
					(int32)Row->Options[i].SwitchToMenu,
					Row->Options[i].NextDialogueID);
			}
		}
	}
	UE_LOG(LogTemp, Error, TEXT("=========================================="));

	// StartDialogueID Ȯ��
	UE_LOG(LogTemp, Error, TEXT("StartDialogueID: %d"), StartDialogueID);

	if (bIsDialogueActive)
	{
		return false;
	}

	CurrentInteractor = Interactor;
	CurrentMenuType = EMenuType::None;
	CurrentDataTable = MainMenuDataTable;
	DialogueHistory.Empty();

	FDialogueRow* DialogueRow = LoadDialogueByID(StartDialogueID);
	if (!DialogueRow)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load dialogue ID: %d"), StartDialogueID);
		return false;
	}

	UE_LOG(LogTemp, Error, TEXT("Loaded DialogueText: %s"), *DialogueRow->DialogueText.ToString());
	UE_LOG(LogTemp, Error, TEXT("Options count: %d"), DialogueRow->Options.Num());

	for (int32 i = 0; i < DialogueRow->Options.Num(); i++)
	{
		UE_LOG(LogTemp, Error, TEXT("  Option %d: %s (Switch: %d)"),
			i,
			*DialogueRow->Options[i].OptionText.ToString(),
			(int32)DialogueRow->Options[i].SwitchToMenu);
	}

	CurrentDialogue = *DialogueRow;
	bIsDialogueActive = true;

	OnDialogueStarted.Broadcast(CurrentDialogue);

	UE_LOG(LogTemp, Error, TEXT("========================================"));
	return true;
}

void UDialogueComponent::EndDialogue()
{
	if (!bIsDialogueActive) return;

	bIsDialogueActive = false;
	CurrentInteractor = nullptr;
	CurrentMenuType = EMenuType::None;
	CurrentDataTable = nullptr;
	DialogueHistory.Empty();

	//�̺�Ʈ�ߵ�
	OnDialogueEnded.Broadcast();
	UE_LOG(LogTemp, Log, TEXT("Dialogue ended"));
}

bool UDialogueComponent::SelectOption(int32 OptionIndex)
{
	if (!bIsDialogueActive) return false;
	if (!CurrentDialogue.Options.IsValidIndex(OptionIndex))
	{
		UE_LOG(LogTemp, Error, TEXT("InValid option index: %d"), OptionIndex);
		return false;
	}
	const FDialogueOption& SelectedOption = CurrentDialogue.Options[OptionIndex];

	UE_LOG(LogTemp, Log, TEXT("Option selected: %s"), *SelectedOption.OptionText.ToString());

	if (!CheckCondition(SelectedOption.RequiredCondition))  // FDialogueCondition�� ����
	{
		UE_LOG(LogTemp, Warning, TEXT("Option condition not met"));
		return false;
	}

	///�޴� ��ȯ Ȯ��
	if (SelectedOption.SwitchToMenu != EMenuType::None)
	{
		if (SelectedOption.SwitchToMenu == EMenuType::Exit)
		{
			EndDialogue();
			return true;
		}
		// �߰�: Trade ó��
		else if (SelectedOption.SwitchToMenu == EMenuType::Trade)
		{
			// ����Ʈ NPC�� �ŷ� �Ұ�
			if (Cast<ANPCCharacter_Quest>(GetOwner()))
			{
				UE_LOG(LogTemp, Warning, TEXT("Quest NPC cannot trade"));
				return false;
			}
			ANPCCharacter* NPC = Cast<ANPCCharacter>(GetOwner());
			if (NPC)
			{
				// ��ȭâ�� �����ϰų� �ݱ� (����)
				EndDialogue();
				NPC->OpenShop();

				return true;
			}
		}
		else if (SelectedOption.SwitchToMenu == EMenuType::Quest)
		{
			// �ŷ� NPC�� ����Ʈ �Ұ�
			ANPCCharacter_Quest* QuestNPC = Cast<ANPCCharacter_Quest>(GetOwner());
			if (!QuestNPC) return false;

			// �÷��̾� ��������
			APlayerCharacter_SB* Player = Cast<APlayerCharacter_SB>(CurrentInteractor);
			if (!Player) return false;

			// �Ϸ� ������ ����Ʈ ���� üũ
			int32 CompletableID = QuestNPC->GetCompletableQuestID(Player);
			if (CompletableID != 0)
			{
				// ����Ʈ ������ �̸� �Ϸ� ���� ��������
				UQuestComponent* QuestComp = Player->FindComponentByClass<UQuestComponent>();
				FQuestDataRow* QuestData = QuestComp ? QuestComp->GetQuestData(CompletableID) : nullptr;

				bool bSuccess = QuestNPC->TryCompleteQuest(Player, CompletableID);

				if (bSuccess && QuestData && QuestNPC->QuestCompleteWidgetClass)
				{
					UQuestCompleteWidget* Popup = CreateWidget<UQuestCompleteWidget>(
						GetWorld(), QuestNPC->QuestCompleteWidgetClass
					);
					if (Popup)
					{
						QuestNPC->ActiveQuestCompleteWidget = Popup;
						Popup->AddToViewport(200);
						Popup->InitializePopup(QuestData->QuestName, QuestData->RewardGold);
					}
				}
				EndDialogue();
				return true;
			}

			// ���� ������ ����Ʈ üũ
			int32 AvailableID = QuestNPC->GetAvailableQuestID(Player);
			if (AvailableID != 0)
			{
				QuestNPC->TryAcceptQuest(Player, AvailableID);
				//SwitchToMenu(EMenuType::Quest);
				EndDialogue();
				return true;
			}

			EndDialogue();
			return true;
		}
	}

		//���� ��ȭ�� �̵� or ����
		if (SelectedOption.NextDialogueID == 0)
		{
			EndDialogue();
			return true;
		}
		else
		{
			GoToDialogue(SelectedOption.NextDialogueID);
			return true;
		}
	}

bool UDialogueComponent::CheckCondition_Implementation(const FDialogueCondition& Condition)
{
	// ���� ����
	if (Condition.ConditionType == EConditionType::None)
	{
		return true;
	}

	// TODO: ���� ���� üũ ���� ����
	// ������ ��� ���� ���
	UE_LOG(LogTemp, Log, TEXT("CheckCondition: Type=%d, Value=%s, Amount=%d"),
		(int32)Condition.ConditionType, *Condition.ConditionValue, Condition.RequiredAmount);

	return true;
}

void UDialogueComponent::GoToDialogue(int32 DialogueID)
{
	if (!CurrentDataTable)
	{
		UE_LOG(LogTemp, Error, TEXT("No active DataTable!"));
		return;
	}

	// �̷� ����
	DialogueHistory.Add(CurrentDialogue.DialogueID);

	FDialogueRow* DialogueRow = LoadDialogueByID(DialogueID);
	if (!DialogueRow)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load dialogue ID: %d"), DialogueID);
		ReturnToMainMenu();
		return;
	}
	CurrentDialogue = *DialogueRow;

	//�̺�Ʈ �ߵ�
	OnDialogueUpdated.Broadcast(CurrentDialogue);

	UE_LOG(LogTemp, Log, TEXT("Dialogue updated: &s"), *CurrentDialogue.DialogueText.ToString());
}

void UDialogueComponent::SwitchToMenu(EMenuType MenuType)
{
	UDataTable* NewDataTable = GetDataTableForMenu(MenuType);

	if (!NewDataTable)
	{
		UE_LOG(LogTemp, Error, TEXT("DataTable not found for menu type: %d"), (int32)MenuType);
		ReturnToMainMenu();
		return;
	}

	// �޴� ��ȯ
	CurrentMenuType = MenuType;
	CurrentDataTable = NewDataTable;
	DialogueHistory.Empty();  // �޴� ��ȯ �� �̷� �ʱ�ȭ

	// �ش� �޴��� ù ��ȭ �ε� (�׻� ID 1���� ����)
	FDialogueRow* DialogueRow = LoadDialogueByID(1);
	if (!DialogueRow)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load first dialogue in menu: %d"), (int32)MenuType);
		ReturnToMainMenu();
		return;
	}

	CurrentDialogue = *DialogueRow;

	OnMenuChanged.Broadcast(MenuType);
	OnDialogueUpdated.Broadcast(CurrentDialogue);

	UE_LOG(LogTemp, Log, TEXT("Switched to menu: %d"), (int32)MenuType);
}

void UDialogueComponent::ReturnToMainMenu()
{
	if (!MainMenuDataTable)
	{
		UE_LOG(LogTemp, Error, TEXT("Cannot return to main menu: MainMenuDataTable is null!"));
		EndDialogue();
		return;
	}

	CurrentMenuType = EMenuType::None;
	CurrentDataTable = MainMenuDataTable;
	DialogueHistory.Empty();

	FDialogueRow* DialogueRow = LoadDialogueByID(StartDialogueID);
	if (!DialogueRow)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to load main menu!"));
		EndDialogue();
		return;
	}

	CurrentDialogue = *DialogueRow;

	OnDialogueUpdated.Broadcast(CurrentDialogue);

	UE_LOG(LogTemp, Log, TEXT("Returned to main menu"));
}

FDialogueRow* UDialogueComponent::LoadDialogueByID(int32 DialogueID)
{
	if (!CurrentDataTable) return nullptr;

	//��� Row�� ��ȸ�ϸ鼭 DialogueID�� ã��
	TArray<FName> RowNames = CurrentDataTable->GetRowNames();

	UE_LOG(LogTemp, Error, TEXT("LoadDialogueByID: Searching for ID %d"), DialogueID);

	for (FName RowName : RowNames)
	{
		FDialogueRow* Row = CurrentDataTable->FindRow<FDialogueRow>(RowName, TEXT("LoadDialogue"));
		if (Row && Row->DialogueID == DialogueID)
		{
			UE_LOG(LogTemp, Error, TEXT("  Found! Row Name: '%s', DialogueID: %d"),
				*RowName.ToString(), Row->DialogueID);
			return Row;
		}
	}

	UE_LOG(LogTemp, Error, TEXT("  NOT FOUND! DialogueID %d"), DialogueID);
	return nullptr;
}

UDataTable* UDialogueComponent::GetDataTableForMenu(EMenuType MenuType)
{
	switch (MenuType)
	{
	case EMenuType::Dialogue:
		return DialogueDataTable;

	case EMenuType::Quest:
		return QuestDataTable;

	case EMenuType::Trade:
		return TradeDataTable;

	default:
		return nullptr;
	}
}
// ShopWidget.h

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ShopWidget.generated.h"

class ANPCCharacter;
class APlayerCharacter_SB;
class UInventoryComponent;
class UShopItemSlot;
class UInventoryItemSlot;
class UWrapBox;
class UBorder;
class UButton;
class UTextBlock;
class UScrollBox;
class UDataTable;

USTRUCT()
struct FSoldItemRecord
{
    GENERATED_BODY()

    UPROPERTY()
    FName ItemRowName = NAME_None;

    UPROPERTY()
    int32 Quantity = 0;

    UPROPERTY()
    int32 GoldEarned = 0;
};

UCLASS()
class STILLBOUND_API UShopWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    // === �ʱ�ȭ ===
    UFUNCTION(BlueprintCallable, Category = "Shop")
    void InitializeShop(ANPCCharacter* InNPCCharacter);

    // === ���� ���ΰ�ħ ===
    UFUNCTION(BlueprintCallable, Category = "Shop")
    void RefreshShop();

    // === ������ ���� ===
    UFUNCTION(BlueprintCallable, Category = "Shop")
    void BuyItem(FName ItemRowName, int32 Quantity = 1);

    // === ���� �ݱ� ===
    UFUNCTION(BlueprintCallable, Category = "Shop")
    void CloseShop();

    void RefreshSoldItems();

protected:
    virtual void NativeConstruct() override;
    virtual void NativeDestruct() override;

    // === Drag & Drop (��ȯ Ÿ�� ����!) ===
    virtual bool NativeOnDrop(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;
    virtual void NativeOnDragEnter(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;
    virtual void NativeOnDragLeave(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

    // === �� ��ȯ ===
    UFUNCTION()
    void OnBuyTabClicked();

    UFUNCTION()
    void OnSellTabClicked();

    void SwitchTab(bool bShowBuyTab);

    // === UI ������Ʈ ===
    void DisplayShopItems();
    void DisplayPlayerInventory();
    void UpdateGoldDisplay();

    // === ��ư �̺�Ʈ ===
    UFUNCTION()
    void OnCloseButtonClicked();

    // === ��� �ʱ�ȭ Ÿ�̸� ===
    UFUNCTION()
    void OnRestockTimer();

    // === �κ��丮 ���� ��������Ʈ ===
    UFUNCTION()
    void OnInventoryUpdated();

    UFUNCTION()
    void OnHotbarUpdated();

    // === Widget ������Ʈ ===

    UPROPERTY(meta = (BindWidget))
    UWrapBox* WB_ShopItems;

    UPROPERTY(meta = (BindWidget))
    UWrapBox* WB_PlayerInventory;

    UPROPERTY(meta = (BindWidget))
    UButton* BTN_BuyTab;

    UPROPERTY(meta = (BindWidget))
    UButton* BTN_SellTab;

    UPROPERTY(meta = (BindWidget))
    UButton* BTN_Close;

    UPROPERTY(meta = (BindWidget))
    UBorder* Border_BuyPanel;

    UPROPERTY(meta = (BindWidget))
    UBorder* Border_SellPanel;

    UPROPERTY(meta = (BindWidget))
    UBorder* Border_LeftPanel;

    UPROPERTY(meta = (BindWidget))
    UBorder* DropZone;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_ShopName;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_PlayerGold;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_DropHint;

    // === Widget Ŭ���� ===

    UPROPERTY(EditDefaultsOnly, Category = "Shop")
    TSubclassOf<UShopItemSlot> ShopItemSlotClass;

    UPROPERTY(EditDefaultsOnly, Category = "Shop")
    TSubclassOf<UInventoryItemSlot> InventoryItemSlotClass;

    UPROPERTY(meta = (BindWidget))
    UScrollBox* SB_SoldItems;

private:
    // === ���� ===

    UPROPERTY()
    ANPCCharacter* NPCCharacter;

    UPROPERTY()
    UInventoryComponent* PlayerInventory;

    UPROPERTY()
    TArray<FSoldItemRecord> SoldItemHistory;

    // === ���� ===
    bool bShowBuyTab;

    // === Ÿ�̸� ===
    FTimerHandle RestockTimerHandle;
};
// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Enum.h"
#include "NPCStateEnum.generated.h"

/**
 * 
 */
UENUM(BlueprintType)
enum class ENPCMode : uint8
{
    Idle            UMETA(DisplayName = "���"),
    Alert           UMETA(DisplayName = "��� (�÷��̾� ����)"),
    Interacting     UMETA(DisplayName = "��ȣ�ۿ� ��"),
    Working         UMETA(DisplayName = "�۾� ��")
};


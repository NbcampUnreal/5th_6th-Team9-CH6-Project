// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "DialogueData.generated.h"

/**
 * 
 */

UENUM(BlueprintType)
enum class EDialogueType : uint8
{
    Normal      UMETA(DisplayName = "Normal"),
    Quest       UMETA(DisplayName = "Quest"),
    Trade       UMETA(DisplayName = "Trade"),
    Information UMETA(DisplayName = "Information")
};

UENUM(BlueprintType)
enum class EMenuType : uint8
{
    None        UMETA(DisplayName = "None"),
    Dialogue    UMETA(DisplayName = "Dialogue"),
    Quest       UMETA(DisplayName = "Quest"),
    Trade       UMETA(DisplayName = "Trade"),
    Exit        UMETA(DisplayName = "EXIT")
};

UENUM(BlueprintType)
enum class EConditionType : uint8
{
    None            UMETA(DisplayName = "���� ����"),
    HasItem         UMETA(DisplayName = "������ ����"),
    HasGold         UMETA(DisplayName = "��� ����"),
    QuestCompleted  UMETA(DisplayName = "����Ʈ �Ϸ�"),
    QuestActive     UMETA(DisplayName = "����Ʈ ���� ��")
};

USTRUCT(BlueprintType)
struct FDialogueCondition
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Condition")
    EConditionType ConditionType = EConditionType::None;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Condition")
    FString ConditionValue;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Condition")
    int32 RequiredAmount = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Condition")
    bool bInvert = false;

    FDialogueCondition()
        : ConditionType(EConditionType::None)
        , ConditionValue("")
        , RequiredAmount(1)
        , bInvert(false)
    {
    }
};

USTRUCT(BlueprintType)
struct FDialogueOption
{
    GENERATED_BODY()

    // ������ �ؽ�Ʈ
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText OptionText;

    // ���� ��ȭ ID (0�̸� ��ȭ ����)
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 NextDialogueID = 0;

    // �޴� ��ȯ (�ٸ� ���̺��� �̵�)
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EMenuType SwitchToMenu = EMenuType::None;

    // ����
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FDialogueCondition RequiredCondition;

    FDialogueOption()
        : OptionText(FText::FromString(TEXT("���")))
        , NextDialogueID(0)
        , SwitchToMenu(EMenuType::None)
    {
    }
};

/**
 * ��ȭ ������ (DataTable Row)
 */
USTRUCT(BlueprintType)
struct FDialogueRow : public FTableRowBase
{
    GENERATED_BODY()

    // ��ȭ ID
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 DialogueID = 0;

    // NPC �̸�
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText NPCName;

    // ��ȭ ����
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText DialogueText;

    // ��ȭ Ÿ��
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EDialogueType DialogueType = EDialogueType::Normal;

    // ������ ���
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FDialogueOption> Options;

    // NPC �ʻ�ȭ (���û���)
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    UTexture2D* NPCPortrait = nullptr;

    FDialogueRow()
    {
    }
};

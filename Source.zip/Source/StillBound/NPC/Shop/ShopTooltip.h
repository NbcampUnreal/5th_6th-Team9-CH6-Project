// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ShopTooltip.generated.h"

class UTextBlock;
struct FItemDataRow;

/**
 * 
 */
UCLASS()
class STILLBOUND_API UShopTooltip : public UUserWidget
{
	GENERATED_BODY()
	
public:
    // ������ ���� + ���� ����
    void SetItemInfo(const FItemDataRow* ItemData, int32 Price);

protected:
    // ���ε� ������
    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_ItemName;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_ItemType;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_ItemDescription;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_ItemPrice;  // �� �߰�!

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TXT_ItemStats;
};

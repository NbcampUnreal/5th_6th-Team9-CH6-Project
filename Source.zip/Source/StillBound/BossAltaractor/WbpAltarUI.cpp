//WbpAltarUI.cpp

#include "BossAltaractor/WbpAltarUI.h"
#include "BossAltaractor/AltarActor.h"
#include "Components/TextBlock.h"
#include "Components/Button.h"
#include "Components/Image.h"

void UWbpAltarUI::NativeConstruct()
{
	Super::NativeConstruct();

	if (Button_Insert)
	{
		Button_Insert->OnClicked.AddDynamic(this, &UWbpAltarUI::OnInsertButtonClicked);
	}

	// �ʱ� ����: ��� ���� ����
	if (TextBlock_Warning)
	{
		TextBlock_Warning->SetVisibility(ESlateVisibility::Hidden);
	}
}

 void UWbpAltarUI::InitWithAltar(AAltaractor* InAltar)
{
	 LinkedAltar = InAltar;
	 RefreshSlots();
}

 void UWbpAltarUI::RefreshSlots()
 {
	 if (!LinkedAltar) return;

	 const int32 Filled = LinkedAltar->GetFilledSlotCount();
	 const int32 Required = LinkedAltar->GetRequiredSlotCount();

	 // ���� �̹��� ������Ʈ
	 for (int32 i = 0; i < Required; ++i)
	 {
		 UImage* SlotImg = GetSlotImage(i);
		 if (!SlotImg) continue;

		 if (i < Filled)
		 {
			 SlotImg->SetBrush(FilledSlotBrush);
		 }
		 else
		 {
			 SlotImg->SetBrush(EmptySlotBrush);
		 }
	 }

	 // ��� ������ ��� ����
	 if (TextBlock_Warning)
	 {
		 TextBlock_Warning->SetVisibility(ESlateVisibility::Hidden);
	 }
 }

void UWbpAltarUI::OnInsertButtonClicked()
{
	if (!LinkedAltar) return;

	const bool bSuccess = LinkedAltar->TryInsertTablet();

	if (!bSuccess)
	{
		// ���� ���� ���
		if (TextBlock_Warning)
		{
			TextBlock_Warning->SetText(
				FText::FromString(TEXT("3 stone tablets are needed"))
			);
			TextBlock_Warning->SetVisibility(ESlateVisibility::Visible);
		}
		return;
	}

	// ���� �� ���� ����, ��� ����
	RefreshSlots();
}

UImage* UWbpAltarUI::GetSlotImage(int32 Index) const
{
	switch (Index)
	{
	case 0: return Slot_0;
	case 1: return Slot_1;
	case 2: return Slot_2;
	default: return nullptr;
	}
}

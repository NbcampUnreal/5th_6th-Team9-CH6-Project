//BossArenawall.h

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BossArenaWall.generated.h"

class UBoxComponent;
class UStaticMeshComponent;

UCLASS()
class STILLBOUND_API ABossArenaWall : public AActor
{
	GENERATED_BODY()
	
public:	
	ABossArenaWall();

protected:

	virtual void BeginPlay() override;

	// ����ŷ �ݸ���
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Wall")
	TObjectPtr<UBoxComponent> WallCollision;

	//������ ���־� �޽� ,���� �庮 ��Ƽ���� ���� ����
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Wall")
	TObjectPtr<UStaticMeshComponent> WallMesh;

public:	

	//AltarActor
	UFUNCTION(BlueprintCallable, Category = "Wall")
	void SetWallSize(float Width, float Height);

	UPROPERTY(BlueprintReadOnly, Category = "Wall")
	FVector WallFullSize = FVector::ZeroVector;
};

﻿#include "Inventory/InventoryComponent.h"
#include "Data/ItemData.h"
#include "Items/ItemBase.h"
#include "GuideQuest/GuideQuestSubsystem.h"

static bool GetRecipeRow(UDataTable* Table, FName RecipeID, FCraftingRecipeRow& OutRow)
{
	if (!Table || RecipeID.IsNone()) return false;
	const FCraftingRecipeRow* Found = Table->FindRow<FCraftingRecipeRow>(RecipeID, TEXT("RecipeLookup"));
	if (!Found) return false;
	OutRow = *Found;
	return true;
}

UInventoryComponent::UInventoryComponent()
{

	PrimaryComponentTick.bCanEverTick = false;

}

void UInventoryComponent::BeginPlay()
{
	Super::BeginPlay();

	InventorySlots.SetNum(InventorySlotsCapacity);

	if (bUseHotbar)
	{
		HotbarContents.SetNum(HotbarSlotsCapacity);
	}
	else
	{
		HotbarSlotsCapacity = 0;
		HotbarContents.Empty();
	}
}

UItemBase* UInventoryComponent::FindMatchingItem(UItemBase* ItemIn) const
{
	if (!ItemIn) return nullptr;

	for (const TObjectPtr<UItemBase>& Ptr : InventorySlots)
	{
		if (Ptr.Get() == ItemIn)
			return ItemIn;
	}
	return nullptr;

}

UItemBase* UInventoryComponent::FindNextItemByID(UItemBase* ItemIn) const
{
	if (!ItemIn) return nullptr;

	for (const TObjectPtr<UItemBase>& Ptr : InventorySlots)
	{
		UItemBase* It = Ptr.Get();
		if (It && It->ID == ItemIn->ID)
			return It;
	}
	return nullptr;

}

UItemBase* UInventoryComponent::FindNextPartialStack(UItemBase* ItemIn) const
{
	if (!ItemIn) return nullptr;

	for (const TObjectPtr<UItemBase>& Ptr : InventorySlots)
	{
		UItemBase* It = Ptr.Get();
		if (It && It->ID == ItemIn->ID && !It->IsFullItemStack())
			return It;
	}
	return nullptr;

}

UItemBase* UInventoryComponent::FindNextPartialStackInHotbar(UItemBase* ItemIn) const
{
	if (!ItemIn) return nullptr;
	
	for (const TObjectPtr<UItemBase>& Ptr : HotbarContents)
	{
		UItemBase* It = Ptr.Get();
		if (It && It->ID == ItemIn->ID && !It->IsFullItemStack())
		{
			return It;
		}
	}
	return nullptr;
}

int32 UInventoryComponent::FindFirstEmptyInventorySlot() const
{
	for (int32 i = 0; i < InventorySlots.Num(); ++i)
	{
		if (InventorySlots[i] == nullptr)
			return i;
	}
	return INDEX_NONE;
}

int32 UInventoryComponent::FindFirstEmptyHotbarIndex() const
{
	for (int32 i = 0; i < HotbarContents.Num(); ++i)
	{
		if (HotbarContents[i] == nullptr)
		{
			return i;
		}
	}
	return INDEX_NONE;
}

int32 UInventoryComponent::CalculateWeightAddAmount(UItemBase* ItemIn, int32 RequestedAddAmount)
{
	const int32 WeightMaxAddAmount = FMath::FloorToInt((GetWeightCapacity() - InventoryTotalWeight) / ItemIn->GetItemSingleWeight());
	if (WeightMaxAddAmount >= RequestedAddAmount)
	{
		return RequestedAddAmount;
	}

	return WeightMaxAddAmount;
}

int32 UInventoryComponent::CalculateNumberForFullStack(UItemBase* StackableItem, int32 InitialRequestedAddAmount)
{
	const int32 AddAmountToMakeFullStack = StackableItem->NumericData.MaxStackSize - StackableItem->Quantity;

	return FMath::Min(InitialRequestedAddAmount, AddAmountToMakeFullStack);
}

void UInventoryComponent::RemoveSingleInstanceOfItem(UItemBase* ItemToRemove)
{
	if (!ItemToRemove) return;

	for (int32 i = 0; i < InventorySlots.Num(); ++i)
	{
		if (InventorySlots[i].Get() == ItemToRemove)
		{
			InventorySlots[i] = nullptr;
			OnInventoryUpdated.Broadcast();
			return;
		}
	}
	// 핫바 탐색
	for (int32 i = 0; i < HotbarContents.Num(); ++i)
	{
		if (HotbarContents[i].Get() == ItemToRemove)
		{
			HotbarContents[i] = nullptr;
			OnHotbarUpdated.Broadcast();
			OnInventoryUpdated.Broadcast();
			return;
		}
	}

}

int32 UInventoryComponent::RemoveAmountOfItem(UItemBase* ItemIn, int32 DesiredAmountToRemove)
{
	const int32 ActualAmountToRemove = FMath::Min(DesiredAmountToRemove, ItemIn->Quantity);

	ItemIn->SetQuantity(ItemIn->Quantity - ActualAmountToRemove);

	InventoryTotalWeight -= ActualAmountToRemove * ItemIn->GetItemSingleWeight();

	OnInventoryUpdated.Broadcast();

	return ActualAmountToRemove;
}

void UInventoryComponent::SplitExistingStack(UItemBase* ItemIn, const int32 AmountToSplit)
{
	if (FindFirstEmptyInventorySlot() != INDEX_NONE)
	{
		RemoveAmountOfItem(ItemIn, AmountToSplit);
		AddNewItem(ItemIn, AmountToSplit);
	}
}

FItemAddResult UInventoryComponent::HandleNonStackableItems(UItemBase* InputItem)
{
	// check if in the input item has valid weight
	if (FMath::IsNearlyZero(InputItem->GetItemSingleWeight()) || InputItem->GetItemSingleWeight() < 0)
	{
		return FItemAddResult::AddedNone(FText::Format(FText::FromString("Could not add {0} to the inventory. Item has invalid weight value."), InputItem->TextData.Name));
	}

	// will the item weight overflow weight capacity
	if (InventoryTotalWeight + InputItem->GetItemSingleWeight() > GetWeightCapacity())
	{
		return FItemAddResult::AddedNone(FText::Format(FText::FromString("Could not add {0} to the inventory. Item would overflow weight limit."), InputItem->TextData.Name));
	}

	// adding one more item would overflow slot capacity
	if (FindFirstEmptyInventorySlot() == INDEX_NONE)
	{
		return FItemAddResult::AddedNone(FText::Format(FText::FromString("Could not add {0} to the inventory. All Inventory slots are full."), InputItem->TextData.Name));
	}

	AddNewItem(InputItem, 1);
	//가이드 퀘스트
	NotifyGuideQuestItemCollected(InputItem->ID, 1);
	//===============
	return FItemAddResult::AddedAll(1, FText::Format(FText::FromString("Successfully added a single {0} to the inventory."), InputItem->TextData.Name));
}

int32 UInventoryComponent::HandleStackableItems(UItemBase* ItemIn, int32 RequestedAddAmount)
{
	if (RequestedAddAmount <= 0 || FMath::IsNearlyZero(ItemIn->GetItemStackWeight()))
	{
		// invalid item data
		return 0;
	}

	int32 AmountToDistribute = RequestedAddAmount;

	// check if the input item already exists in the inventory and is not a full stack
	UItemBase* ExistingItemStack = FindNextPartialStack(ItemIn);

	// distribute time stack over existing stacks
	while (ExistingItemStack)
	{
		// calculate how many of the existing item would be needed to make the next full stack
		const int32 AmountToMakeFullStack = CalculateNumberForFullStack(ExistingItemStack, AmountToDistribute);
		// calculate how many of the AmountToMakeFullStack can actually be carried based on weight capacity
		const int32 WeightLimitAddMount = CalculateWeightAddAmount(ExistingItemStack, AmountToMakeFullStack);

		// as long as the remaining amount of the item does noet overflow weight capacity
		if (WeightLimitAddMount > 0)
		{
			// adjust the existing items stack quantity and inventory total weight
			ExistingItemStack->SetQuantity(ExistingItemStack->Quantity + WeightLimitAddMount);
			InventoryTotalWeight += ExistingItemStack->GetItemSingleWeight() * WeightLimitAddMount;

			// adjust the count to be distributed
			AmountToDistribute -= WeightLimitAddMount;

			ItemIn->SetQuantity(AmountToDistribute);

			// TODO: Refine this logic since going over weight capacity should not ever be possible
			// if max weight capacity is reached, no need to run the loop again
			if (InventoryTotalWeight >= InventoryWeightCapacity)
			{
				OnInventoryUpdated.Broadcast();
				return RequestedAddAmount - AmountToDistribute;

			}
		}
		else if (WeightLimitAddMount <= 0)
		{
			if (AmountToDistribute != RequestedAddAmount)
			{
				// this block will be reached if distributing an item across multiple stacks
				// and the weight limit is hit during that process
				OnInventoryUpdated.Broadcast();
				return RequestedAddAmount - AmountToDistribute;
			}

			return 0;
		}

		if (AmountToDistribute <= 0)
		{
			// all of the input item was distributed across existing stacks
			OnInventoryUpdated.Broadcast();
			return RequestedAddAmount;
		}

		// check if there is still another valid partial stack of the input item
		ExistingItemStack = FindNextPartialStack(ItemIn);
	}

	// no more partial stacks found, check if a new stack can be added
	if (FindFirstEmptyInventorySlot() != INDEX_NONE)
	{
		// attempt to add as many from the remaining item quantity that can fit inventory weight capacity
		const int32 WeightLimitAddAmount = CalculateWeightAddAmount(ItemIn, AmountToDistribute);

		if (WeightLimitAddAmount > 0)
		{
			// if there is still more item to distribute, but weight limit has been reached
			if (WeightLimitAddAmount < AmountToDistribute)
			{
				// adjust the input item and add a new stack with as many as can be held
				AmountToDistribute -= WeightLimitAddAmount;
				ItemIn->SetQuantity(AmountToDistribute);

				// create a copy since only a partial stack is being added
				AddNewItem(ItemIn->CreateItemCopy(), WeightLimitAddAmount);
				return RequestedAddAmount - AmountToDistribute;
			}

			// otherwise, the full remainder of the stack can be added
			AddNewItem(ItemIn, AmountToDistribute);
			return RequestedAddAmount;
		}
	}

	OnInventoryUpdated.Broadcast();
	return RequestedAddAmount - AmountToDistribute;
}

FItemAddResult UInventoryComponent::HandleAddItem(UItemBase* InputItem)
{
	if (GetOwner())
	{
		const int32 InitialRequestedAddAmount = InputItem->Quantity;

		// handle non-stackable items
		if (!InputItem->NumericData.bIsStackable)
		{
			return HandleNonStackableItems(InputItem);
		}

		// handle stackable
		const int32 StackableAmountAdded = HandleStackableItems(InputItem, InitialRequestedAddAmount);

		if (StackableAmountAdded == InitialRequestedAddAmount)
		{
			//가이드 퀘스트
			NotifyGuideQuestItemCollected(InputItem->ID, StackableAmountAdded);
			//===============

			return FItemAddResult::AddedAll(InitialRequestedAddAmount, FText::Format(
				FText::FromString("Succeesfully added {0} {1} to the inventory."), InitialRequestedAddAmount, InputItem->TextData.Name));
		}

		if (StackableAmountAdded < InitialRequestedAddAmount && StackableAmountAdded>0)
		{
			//가이드 퀘스트
			NotifyGuideQuestItemCollected(InputItem->ID, StackableAmountAdded);
			//===============

			return FItemAddResult::AddedPartial(StackableAmountAdded, FText::Format(
				FText::FromString("Partial amount of {0} added to the inventory. Number added = {1}"), InputItem->TextData.Name, StackableAmountAdded));
		}

		if (StackableAmountAdded <= 0)
		{
			return FItemAddResult::AddedNone(FText::Format(
				FText::FromString("Couldn't add {0} to the inventory. No remaining inventory slots, or invalid item."), InputItem->TextData.Name));
		}
	}

	check(false);
	return FItemAddResult::AddedNone(FText::FromString("TryAddItem fallthrough error. GetOwner() check somehow failed."));
}

FItemAddResult UInventoryComponent::HandleAddItem_AutoHotbarFirst(UItemBase* InputItem)
{
	if (!GetOwner() || !InputItem)
	{
		return FItemAddResult::AddedNone(FText::FromString("Invalid Owner or item."));
	}

	const int32 InitialRequestedAddAmount = InputItem->Quantity;


	/// Non-stackable : 핫바 빈칸 먼저///
	if (!InputItem->NumericData.bIsStackable)
	{
		if (FMath::IsNearlyZero(InputItem->GetItemSingleWeight()) || InputItem->GetItemSingleWeight() < 0)
		{
			return FItemAddResult::AddedNone(FText::Format(FText::FromString("Could not add {0}. Invalid weight."), InputItem->TextData.Name));
		}

		if (InventoryTotalWeight + InputItem->GetItemSingleWeight() > GetWeightCapacity())
		{
			return FItemAddResult::AddedNone(FText::Format(FText::FromString("Could not add {0}. Weight limit reached."), InputItem->TextData.Name));
		}

		const int32 EmptyIdx = FindFirstEmptyHotbarIndex();
		if (EmptyIdx != INDEX_NONE)
		{
			UItemBase* NewItem = nullptr;

			if (InputItem->bIsCopy || InputItem->bIsPickup)
			{
				NewItem = InputItem;
				NewItem->ResetItemFlags();
			}
			else
			{
				NewItem = InputItem->CreateItemCopy();
			}

			NewItem->OwningInventory = this;
			NewItem->SetQuantity(1);

			HotbarContents[EmptyIdx] = NewItem;
			InventoryTotalWeight += NewItem->GetItemSingleWeight();

			OnHotbarUpdated.Broadcast();
			OnInventoryUpdated.Broadcast();

			//가이드 퀘스트
			NotifyGuideQuestItemCollected(InputItem->ID, 1);
			//===============

			return FItemAddResult::AddedAll(1, FText::Format(FText::FromString("Added {0} to hotbar slot {1}."), InputItem->TextData.Name, FText::AsNumber(EmptyIdx + 1)));
		}

		//핫바가 꽉 찼으면 기존 인벤 로직으로
		return HandleNonStackableItems(InputItem);
	}

	/// stackable: 핫바 부분스택 -> 핫바 빈칸 -> 인벤 ///
	int32 AmountToDistribute = InitialRequestedAddAmount;

	//핫바 부분 스택 채우기
	UItemBase* ExistingHotbarStack = FindNextPartialStackInHotbar(InputItem);
	while (ExistingHotbarStack && AmountToDistribute > 0)
	{
		const int32 AmountToMakeFullStack = CalculateNumberForFullStack(ExistingHotbarStack, AmountToDistribute);
		const int32 WeightLimitAddAmount = CalculateWeightAddAmount(ExistingHotbarStack, AmountToMakeFullStack);

		if (WeightLimitAddAmount <= 0)
		{
			break;
		}

		ExistingHotbarStack->SetQuantity(ExistingHotbarStack->Quantity + WeightLimitAddAmount);
		InventoryTotalWeight += ExistingHotbarStack->GetItemSingleWeight() * WeightLimitAddAmount;

		AmountToDistribute -= WeightLimitAddAmount;

		ExistingHotbarStack = FindNextPartialStackInHotbar(InputItem);
	}

	//핫바 빈칸에 새 스택 만들기
	while (AmountToDistribute > 0)
	{
		const int32 EmptyIdx = FindFirstEmptyHotbarIndex();
		if (EmptyIdx == INDEX_NONE) break;

		const int32 ToFullStack = FMath::Min(AmountToDistribute, InputItem->NumericData.MaxStackSize);
		const int32 WeightLimitAddAmount = CalculateWeightAddAmount(InputItem, ToFullStack);

		if (WeightLimitAddAmount <= 0) break;

		// New 스택아이템 만들기 : 부분이면 copy 필요
		UItemBase* NewStack = nullptr;
		if (WeightLimitAddAmount < AmountToDistribute)
		{
			//부분 스택일 가능성 있으니 copy로 안정
			NewStack = InputItem->CreateItemCopy();
		}
		else
		{
			//다 넣을 거면 원본 써도되지만 월드 픽업 여부에 따라 안전하게 copy
			NewStack = InputItem->bIsPickup ? InputItem : InputItem->CreateItemCopy();
		}

		NewStack->ResetItemFlags();
		NewStack->OwningInventory = this;
		NewStack->SetQuantity(WeightLimitAddAmount);

		HotbarContents[EmptyIdx] = NewStack;
		InventoryTotalWeight += NewStack->GetItemSingleWeight() * WeightLimitAddAmount;

		AmountToDistribute -= WeightLimitAddAmount;
	}

	//핫바에 넣은 만큼
	const int32 AddedToHotbar = InitialRequestedAddAmount - AmountToDistribute;

	if (AddedToHotbar > 0)
	{
		OnHotbarUpdated.Broadcast();
		OnInventoryUpdated.Broadcast();
	}

	//남은 수량은 기존 인벤 로직으로
	if (AmountToDistribute > 0)
	{
		//InputItem 수량을 남은 만큼으로 맞추고 HandleAddItem 호출
		InputItem->SetQuantity(AmountToDistribute);
		const FItemAddResult InvResult = HandleAddItem(InputItem);

		//결과 합치기(핫바+인벤)
		const int32 TotalAdded = AddedToHotbar + InvResult.ActualAmountAdded;

		if (TotalAdded <= 0)
		{
			return FItemAddResult::AddedNone(FText::Format(FText::FromString("Couldn't add {0} (hotbar full + inventory full/weight)."), InputItem->TextData.Name));
		}

		if (TotalAdded < InitialRequestedAddAmount)
		{
			return FItemAddResult::AddedPartial(TotalAdded, FText::Format(FText::FromString("Added {0} partially (hotbar+inventory)."), InputItem->TextData.Name));
		}
		
		//가이드 퀘스트
		NotifyGuideQuestItemCollected(InputItem->ID, TotalAdded);
		//===============

		return FItemAddResult::AddedAll(TotalAdded, FText::Format(FText::FromString("Added{0} fully (hotbar+Inventory)."), InputItem->TextData.Name));
	}

	//핫바에서 전부 소화

	//가이드 퀘스트
	NotifyGuideQuestItemCollected(InputItem->ID, InitialRequestedAddAmount);
	//===============
	return FItemAddResult::AddedAll(InitialRequestedAddAmount, FText::Format(FText::FromString("Added {0} to hotbar."), InputItem->TextData.Name));
}

void UInventoryComponent::AddNewItem(UItemBase* Item, const int32 AmountToAdd)
{
	const int32 EmptySlot = FindFirstEmptyInventorySlot();
	if (EmptySlot == INDEX_NONE)
	{
		OnInventoryUpdated.Broadcast();
		return;
	}

	UItemBase* NewItem = nullptr;

	if (Item->bIsCopy || Item->bIsPickup)
	{
		NewItem = Item;
		NewItem->ResetItemFlags();
	}
	else
	{
		NewItem = Item->CreateItemCopy();
	}

	NewItem->OwningInventory = this;
	NewItem->SetQuantity(AmountToAdd);

	InventorySlots[EmptySlot] = NewItem;

	InventoryTotalWeight += NewItem->GetItemStackWeight();
	OnInventoryUpdated.Broadcast();
}

int32 UInventoryComponent::GetOccupiedSlotCount() const
{
	int32 Count = 0;
	for (const TObjectPtr<UItemBase>& Ptr : InventorySlots)
	{
		if (Ptr)
		{
			++Count;
		}
	}
	for (const TObjectPtr<UItemBase>& Ptr : HotbarContents)
	{
		if (Ptr)
		{
			++Count;
		}
	}
	return Count;
}

UItemBase* UInventoryComponent::GetItemAtIndex(int32 Index) const
{
	return InventorySlots.IsValidIndex(Index) ? InventorySlots[Index].Get() : nullptr;
}

int32 UInventoryComponent::RemoveAmountAtIndex(int32 Index, int32 Quantity)
{
	if (!InventorySlots.IsValidIndex(Index)) return 0;

	UItemBase* Item = InventorySlots[Index].Get();
	if (!Item) return 0;

	const int32 Removed = FMath::Min(Quantity, Item->Quantity);
	Item->SetQuantity(Item->Quantity - Removed);

	InventoryTotalWeight -= Removed * Item->GetItemSingleWeight();

	if (Item->Quantity <= 0)
	{
		InventorySlots[Index] = nullptr;
	}

	OnInventoryUpdated.Broadcast();
	return Removed;
}

UItemBase* UInventoryComponent::GetItemInContainer(ESlotContainer InContainer, int32 Index) const
{
	const TArray<TObjectPtr<UItemBase>>& Arr = (InContainer == ESlotContainer::Inventory) ? InventorySlots : HotbarContents;

	return Arr.IsValidIndex(Index) ? Arr[Index].Get() : nullptr;
}

int32 UInventoryComponent::RemoveAmountInContainer(ESlotContainer InContainer, int32 Index, int32 Quantity)
{
	TArray<TObjectPtr<UItemBase>>& Arr = (InContainer == ESlotContainer::Inventory) ? InventorySlots : HotbarContents;

	if (!Arr.IsValidIndex(Index)) return 0;

	UItemBase* Item = Arr[Index].Get();
	if (!Item) return 0;

	const int32 Removed = FMath::Min(Quantity, Item->Quantity);
	Item->SetQuantity(Item->Quantity - Removed);

	InventoryTotalWeight -= Removed * Item->GetItemSingleWeight();

	if (Item->Quantity <= 0)
	{
		Arr[Index] = nullptr;
	}

	if (InContainer == ESlotContainer::Inventory)
	{
		OnInventoryUpdated.Broadcast();
	}
	
	else
	{
		OnHotbarUpdated.Broadcast();
		OnInventoryUpdated.Broadcast();
	}

	return Removed;
}

bool UInventoryComponent::MoveSlotItem(ESlotContainer FromContainer, int32 FromIndex, ESlotContainer ToContainer, int32 ToIndex, bool bAllowSwap)
{
	TArray<TObjectPtr<UItemBase>>& FromArr = (FromContainer == ESlotContainer::Inventory) ? InventorySlots : HotbarContents;
	TArray<TObjectPtr<UItemBase>>& ToArr = (ToContainer == ESlotContainer::Inventory) ? InventorySlots : HotbarContents;

	if (!FromArr.IsValidIndex(FromIndex) || !ToArr.IsValidIndex(ToIndex)) return false;
	if (FromArr[FromIndex] == nullptr) return false;

	if (FromContainer == ToContainer && FromIndex == ToIndex) return false;

	if (ToArr[ToIndex] == nullptr)
	{
		ToArr[ToIndex] = FromArr[FromIndex];
		FromArr[FromIndex] = nullptr;
	}
	else
	{
		if (!bAllowSwap) return false;

		Swap(FromArr[FromIndex], ToArr[ToIndex]);
	}

	if (FromContainer == ESlotContainer::Inventory || ToContainer == ESlotContainer::Inventory)
		OnInventoryUpdated.Broadcast();

	if (FromContainer == ESlotContainer::Hotbar || ToContainer == ESlotContainer::Hotbar)
		OnHotbarUpdated.Broadcast();

	UE_LOG(LogTemp, Warning, TEXT("[MoveSlotItem] From(%d,%d) To(%d,%d)  FromNum=%d ToNum=%d"),
		(int32)FromContainer, FromIndex, (int32)ToContainer, ToIndex,
		FromArr.Num(), ToArr.Num());

	return true;
}

int32 UInventoryComponent::GetTotalCountByID(FName ItemID) const
{
	int32 Total = 0;

	for (const TObjectPtr<UItemBase>& Ptr : InventorySlots)
	{
		const UItemBase* It = Ptr.Get();
		if (It && It->ID == ItemID)
		{
			Total += It->Quantity;
		}
	}

	for (const TObjectPtr<UItemBase>& Ptr : HotbarContents)
	{
		const UItemBase* It = Ptr.Get();
		if (It && It->ID == ItemID)
		{
			Total += It->Quantity;
		}
	}

	return Total;
}

bool UInventoryComponent::ConsumeByID(FName ItemID, int32 Count)
{
	if (ItemID.IsNone() || Count <= 0) return false;
	
	int32 Remaining = Count;

	//핫바 재료 차감
	for (int32 i = 0; i < HotbarContents.Num() && Remaining > 0; ++i)
	{
		UItemBase* It = HotbarContents[i].Get();
		if (!It || It->ID != ItemID) continue;

		const int32 Removed = RemoveAmountInContainer(ESlotContainer::Hotbar, i, Remaining);
		Remaining -= Removed;
	}

	//인벤 재료 차감
	for (int32 i = 0; i < InventorySlots.Num() && Remaining > 0; ++i)
	{
		UItemBase* It = InventorySlots[i].Get();
		if (!It || It->ID != ItemID) continue;

		const int32 Removed = RemoveAmountInContainer(ESlotContainer::Inventory, i, Remaining);
		Remaining -= Removed;
	}

	return Remaining == 0;
}

bool UInventoryComponent::AddByID(FName ItemID, int32 Count)
{
	UItemBase* NewItem = CreateItemInstanceByID(ItemID, Count);

	if (!NewItem) return false;

	const FItemAddResult Res = HandleAddItem_AutoHotbarFirst(NewItem);

	return Res.ActualAmountAdded == Count;
}

//UItemBase* UInventoryComponent::CreateItemInstanceByID(FName ItemID, int32 Quantity) const
//{
//	if (ItemID.IsNone() || Quantity <= 0) return nullptr;
//	if (!ItemDataTable)
//	{
//		UE_LOG(LogTemp, Error, TEXT("[Craft] ItemDataTable is null"));
//		return nullptr;
//	}
//
//	const FItemDataRow* ItemData = ItemDataTable->FindRow<FItemDataRow>(ItemID, TEXT("CraftCreateItem"));
//	if (!ItemData)
//	{
//		UE_LOG(LogTemp, Error, TEXT("[Craft] ItemData not found: %s"), *ItemID.ToString());
//		return nullptr;
//	}
//
//
//	UItemBase* NewItem = NewObject<UItemBase>(GetOwner());
//	if (!NewItem) return nullptr;
//
//	NewItem->ID = ItemID;
//	NewItem->ItemType = ItemData->ItemType;
//	NewItem->ItemQuality = ItemData->ItemQuality;
//	NewItem->NumericData = ItemData->NumericData;
//	NewItem->TextData = ItemData->TextData;
//	NewItem->AssetData = ItemData->AssetData;
//	NewItem->PickupActorClass = ItemData->PickupActorClass;
//
//	NewItem->NumericData.bIsStackable = (ItemData->NumericData.MaxStackSize > 1);
//
//	NewItem->OwningInventory = const_cast<UInventoryComponent*>(this);
//	NewItem->ResetItemFlags();
//	NewItem->SetQuantity(Quantity);
//
//	return NewItem;
//}

UItemBase* UInventoryComponent::CreateItemInstanceByID(FName ItemID, int32 Quantity) const
{
	if (ItemID.IsNone() || Quantity <= 0) return nullptr;

	if (!ItemDataTable)
	{
		UE_LOG(LogTemp, Error, TEXT("[Craft] ItemDataTable is null"));
		return nullptr;
	}

	const FItemDataRow* ItemData = ItemDataTable->FindRow<FItemDataRow>(ItemID, TEXT("CraftCreateItem"));
	if (!ItemData)
	{
		UE_LOG(LogTemp, Error, TEXT("[Craft] ItemData not found: %s"), *ItemID.ToString());
		return nullptr;
	}

	UItemBase* NewItem = NewObject<UItemBase>(GetOwner());
	if (!NewItem) return nullptr;

	NewItem->ID = ItemData->ID;
	NewItem->ItemType = ItemData->ItemType;
	NewItem->ItemQuality = ItemData->ItemQuality;

	NewItem->ItemStatistics = ItemData->ItemStatistics;
	NewItem->TextData = ItemData->TextData;
	NewItem->NumericData = ItemData->NumericData;
	NewItem->AssetData = ItemData->AssetData;

	NewItem->PickupActorClass = ItemData->PickupActorClass;
	NewItem->EquipWeaponClass = ItemData->EquipWeaponClass;
	NewItem->ConsumableEffectClass = ItemData->ConsumableEffectClass;
	NewItem->ConsumableSetByCallerTag = ItemData->ConsumableSetByCallerTag;

	NewItem->NumericData.bIsStackable = (ItemData->NumericData.MaxStackSize > 1);

	NewItem->OwningInventory = const_cast<UInventoryComponent*>(this);
	NewItem->ResetItemFlags();
	NewItem->SetQuantity(Quantity);

	return NewItem;
}

bool UInventoryComponent::CanCraft(FName RecipeID, int32 CraftCount, TArray<FCraftMissing>& OutMissing) const
{
	OutMissing.Reset();
	if (CraftCount <= 0)
	{
		CraftCount = 1;
	}

	FCraftingRecipeRow Row;
	if (!GetRecipeRow(RecipeDataTable, RecipeID, Row))
	{
		return false;
	}

	if (!Row.RequiredStationTag.IsNone() && Row.RequiredStationTag != CurrentStationTag)
	{
		return false;
	}

	for (const FRecipeIngredient& Ing : Row.Ingredients)
	{
		const int32 Need = Ing.Count * CraftCount;
		const int32 Have = GetTotalCountByID(Ing.ItemID);

		if (Have < Need)
		{
			FCraftMissing M;
			M.ItemID = Ing.ItemID;
			M.Needed = Need;
			M.Have = Have;
			OutMissing.Add(M);
		}
	}

	return OutMissing.Num() == 0;
}

FCraftResult UInventoryComponent::Craft(FName RecipeID, int32 CraftCount)
{
	FCraftResult R;
	if (CraftCount <= 0)
	{
		CraftCount = 1;
	}

	FCraftingRecipeRow Row;
	if (!GetRecipeRow(RecipeDataTable, RecipeID, Row))
	{
		R.Message = FText::FromString(TEXT("Recipe not found"));
		return R;
	}

	if (!Row.RequiredStationTag.IsNone() && Row.RequiredStationTag != CurrentStationTag)
	{
		R.Message = FText::FromString(TEXT("Wrong station"));
		return R;
	}

	TArray<FCraftMissing> Missing;
	if (!CanCraft(RecipeID, CraftCount, Missing))
	{
		R.Message = FText::FromString(TEXT("Not enough materials"));
		return R;
	}

	for (const FRecipeIngredient& Ing : Row.Ingredients)
	{
		const int32 ConsumeCount = Ing.Count * CraftCount;
		if (!ConsumeByID(Ing.ItemID, ConsumeCount))
		{
			R.Message = FText::FromString(TEXT("Consume failed"));
			return R;
		}
	}

	const int32 GiveCount = Row.ResultCount * CraftCount;
	if (!AddByID(Row.ResultItemID, GiveCount))
	{
		R.Message = FText::FromString(TEXT("Inventory full"));
		return R;
	}

	OnInventoryUpdated.Broadcast();

	//가이드 퀘스트
	NotifyGuideQuestCrafted(Row.ResultItemID, GiveCount);
	//===============

	R.bSuccess = true;
	R.Message = FText::FromString(TEXT("Craft success"));
	return R;
}

bool UInventoryComponent::GetRecipeRowForUI(FName RecipeID, FCraftingRecipeRow& OutRow) const
{
	if (!RecipeDataTable || RecipeID.IsNone()) return false;

	const FCraftingRecipeRow* Found = RecipeDataTable->FindRow<FCraftingRecipeRow>(RecipeID, TEXT("GetRecipeRowForUI"));

	if (!Found) return false;

	OutRow = *Found;
	return true;
}

int32 UInventoryComponent::GetTotalCountByID_ForUI(FName ItemID) const
{
	return GetTotalCountByID(ItemID);

}

void UInventoryComponent::BuildSaveData(TArray<FSBItemSlotSaveData>& OutInv, TArray<FSBItemSlotSaveData>& OutHotbar) const
{
	OutInv.Reset();
	OutHotbar.Reset();

	for (int32 i = 0; i < InventorySlots.Num(); ++i)
	{
		UItemBase* It = InventorySlots[i].Get();
		if (!It) continue;

		FSBItemSlotSaveData D;
		D.ItemID = It->ID;
		D.Quantity = It->Quantity;
		D.Index = i;
		OutInv.Add(D);
	}

	for (int32 i = 0; i < HotbarContents.Num(); ++i)
	{
		UItemBase* It = HotbarContents[i].Get();
		if (!It) continue;

		FSBItemSlotSaveData D;
		D.ItemID = It->ID;
		D.Quantity = It->Quantity;
		D.Index = i;
		OutHotbar.Add(D);
	}
}

void UInventoryComponent::ApplySaveData(const TArray<FSBItemSlotSaveData>& InInv, const TArray<FSBItemSlotSaveData>& InHotbar)
{
	// 슬롯 초기화
	InventorySlots.SetNum(InventorySlotsCapacity);
	HotbarContents.SetNum(HotbarSlotsCapacity);

	for (int32 i = 0; i < InventorySlots.Num(); ++i) InventorySlots[i] = nullptr;
	for (int32 i = 0; i < HotbarContents.Num(); ++i) HotbarContents[i] = nullptr;

	InventoryTotalWeight = 0.f;

	// 인벤 복원
	for (const auto& D : InInv)
	{
		if (D.ItemID.IsNone() || D.Quantity <= 0) continue;
		if (!InventorySlots.IsValidIndex(D.Index)) continue;

		UItemBase* NewItem = CreateItemInstanceByID(D.ItemID, D.Quantity);

		if (!NewItem)
		{
			UE_LOG(LogTemp, Error, TEXT("[Load] 인벤토리 아이템 생성 실패! ID: %s"), *D.ItemID.ToString());
			continue;
		}

		if (!NewItem) continue;

		NewItem->OwningInventory = this;
		InventorySlots[D.Index] = NewItem;
		InventoryTotalWeight += NewItem->GetItemStackWeight();
	}

	// 핫바 복원
	for (const auto& D : InHotbar)
	{
		if (D.ItemID.IsNone() || D.Quantity <= 0) continue;
		if (!HotbarContents.IsValidIndex(D.Index)) continue;

		UItemBase* NewItem = CreateItemInstanceByID(D.ItemID, D.Quantity);

		if (!NewItem)
		{
			UE_LOG(LogTemp, Error, TEXT("[Load] 핫바 아이템 생성 실패! ID: %s"), *D.ItemID.ToString());
			continue;
		}

		if (!NewItem) continue;

		NewItem->OwningInventory = this;
		HotbarContents[D.Index] = NewItem;
		InventoryTotalWeight += NewItem->GetItemStackWeight();
	}

	OnHotbarUpdated.Broadcast();
	OnInventoryUpdated.Broadcast();
}

void UInventoryComponent::SetUseHotbar(bool bInUseHotbar)
{
	bUseHotbar = bInUseHotbar;

	if (!bUseHotbar)
	{
		HotbarSlotsCapacity = 0;
		HotbarContents.Empty();
	}
}

bool UInventoryComponent::TransferItemToInventory(UInventoryComponent* TargetInventory, ESlotContainer FromContainer, int32 FromIndex, int32 TransferQuantity)
{
	if (!TargetInventory || TransferQuantity <= 0) return false;

	UItemBase* SourceItem = GetItemInContainer(FromContainer, FromIndex);
	if (!SourceItem) return false;

	const int32 ActualTransferQuantity = FMath::Min(TransferQuantity, SourceItem->Quantity);
	if (ActualTransferQuantity <= 0) return false;

	UItemBase* TransferItem = SourceItem->CreateItemCopy();
	if (!TransferItem) return false;

	TransferItem->SetQuantity(ActualTransferQuantity);
	TransferItem->OwningInventory = TargetInventory;
	TransferItem->ResetItemFlags();

	const bool bTargetWantsHotbar = TargetInventory->GetUseHotbar();
	const FItemAddResult AddResult = bTargetWantsHotbar ? TargetInventory->HandleAddItem_AutoHotbarFirst(TransferItem) : TargetInventory->HandleAddItem(TransferItem);

	if (AddResult.ActualAmountAdded <= 0) return false;

	const int32 Removed = RemoveAmountInContainer(FromContainer, FromIndex, AddResult.ActualAmountAdded);

	if (Removed != AddResult.ActualAmountAdded)
	{
		TargetInventory->ConsumeByID(SourceItem->ID, AddResult.ActualAmountAdded);
		return false;
	}

	OnInventoryUpdated.Broadcast();
	TargetInventory->OnInventoryUpdated.Broadcast();

	if (FromContainer == ESlotContainer::Hotbar)
	{
		OnHotbarUpdated.Broadcast();
	}

	if (bTargetWantsHotbar)
	{
		TargetInventory->OnInventoryUpdated.Broadcast();
	}

	return true;
}

bool UInventoryComponent::AddItemByInstance(UItemBase* ItemInstance, bool bAutoHotbarForTarget)
{
	if (!ItemInstance) return false;

	const FItemAddResult Result = (bAutoHotbarForTarget && bUseHotbar) ? HandleAddItem_AutoHotbarFirst(ItemInstance) : HandleAddItem(ItemInstance);

	return Result.ActualAmountAdded == ItemInstance->Quantity;
}

void UInventoryComponent::GetAllItems(TArray<UItemBase*>& OutItems) const
{
	OutItems.Reset();

	for (const TObjectPtr<UItemBase>& Ptr : InventorySlots)
	{
		if (Ptr)
		{
			OutItems.Add(Ptr.Get());
		}
	}

	for (const TObjectPtr<UItemBase>& Ptr : HotbarContents)
	{
		if (Ptr)
		{
			OutItems.Add(Ptr.Get());
		}
	}
}

//가이드 퀘스트
void UInventoryComponent::NotifyGuideQuestItemCollected(FName ItemID, int32 AddedAmount) const
{
	if (ItemID.IsNone() || AddedAmount <= 0)
	{
		return;
	}

	if (!GetWorld() || !GetWorld()->GetGameInstance())
	{
		return;
	}

	if (UGuideQuestSubsystem* QuestSys = GetWorld()->GetGameInstance()->GetSubsystem<UGuideQuestSubsystem>())
	{
		////디버깅용 코드
		UE_LOG(LogTemp, Warning, TEXT("[GuideQuest] NotifyGuideQuestItemCollected called: ItemID=%s AddedAmount=%d"),
			*ItemID.ToString(), AddedAmount);

		QuestSys->ReportCollectItem(ItemID, AddedAmount);
	}
}

void UInventoryComponent::NotifyGuideQuestCrafted(FName ItemID, int32 CraftedAmount) const
{
	if (ItemID.IsNone() || CraftedAmount <= 0)
	{
		return;
	}

	if (!GetWorld() || !GetWorld()->GetGameInstance())
	{
		return;
	}

	if (UGuideQuestSubsystem* QuestSys = GetWorld()->GetGameInstance()->GetSubsystem<UGuideQuestSubsystem>())
	{
		//디버깅용 코드
		UE_LOG(LogTemp, Warning, TEXT("[GuideQuest] NotifyGuideQuestCrafted called: ItemID=%s CraftedAmount=%d"),
			*ItemID.ToString(), CraftedAmount);

		QuestSys->ReportCraftItem(ItemID, CraftedAmount);
	}
}
//===============
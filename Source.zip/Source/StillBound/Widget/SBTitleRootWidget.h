// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "SBTitleRootWidget.generated.h"

/**
 * 
 */
UCLASS()
class STILLBOUND_API USBTitleRootWidget : public UUserWidget
{
	GENERATED_BODY()
	
};

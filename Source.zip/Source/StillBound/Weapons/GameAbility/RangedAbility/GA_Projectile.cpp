#include "Weapons/GameAbility/RangedAbility/GA_Projectile.h"

#include "Weapons/RangedWeapon/RangedWeaponBase.h"
#include "Weapons/RangedWeapon/ProjectileBase.h"
#include "Weapons/WeaponBase.h"
#include "Character/PlayerCharacter_SB.h"

#include "AbilitySystemComponent.h"
#include "GameplayTagContainer.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"

namespace
{
    static TArray<FProjectileOnHitGameplayEffectSpec> ConvertToProjectileOnHitSpecs(
        const TArray<FRangedOnHitGameplayEffectSpec>& InSpecs)
    {
        TArray<FProjectileOnHitGameplayEffectSpec> OutSpecs;
        OutSpecs.Reserve(InSpecs.Num());

        for (const FRangedOnHitGameplayEffectSpec& InSpec : InSpecs)
        {
            FProjectileOnHitGameplayEffectSpec OutSpec;
            OutSpec.Effect = InSpec.Effect;
            OutSpec.Level = InSpec.Level;
            OutSpec.SetByCallerMagnitudes = InSpec.SetByCallerMagnitudes;
            OutSpec.Chance = InSpec.Chance;
            OutSpecs.Add(MoveTemp(OutSpec));
        }

        return OutSpecs;
    }

    static FProjectileImpactFXPayload ConvertToProjectileImpactFXPayload(const AWeaponBase* Weapon)
    {
        FProjectileImpactFXPayload OutPayload;

        if (!Weapon)
        {
            return OutPayload;
        }

        const FWeaponHitImpactFX& WeaponFX = Weapon->GetHitImpactFX();
        OutPayload.NiagaraSystem = WeaponFX.NiagaraSystem;
        OutPayload.Scale = WeaponFX.Scale;
        OutPayload.LocationOffset = WeaponFX.LocationOffset;
        OutPayload.RotationOffset = WeaponFX.RotationOffset;
        OutPayload.bUseImpactNormalRotation = WeaponFX.bUseImpactNormalRotation;

        return OutPayload;
    }
}

UGA_Projectile::UGA_Projectile()
{
    // ��Ÿ�� ��Ƽ���� Ÿ�ֿ̹� �߻� �̺�Ʈ
    FireEventTag = FGameplayTag::RequestGameplayTag(TEXT("Event.Ranged.Fire"), false);

    // ��Ÿ��/�̺�Ʈ�� ������ ��� �߻�
    bFireImmediatelyIfNoMontageOrEvent = true;

    // �����
    bDebugTrace = false;
    DebugLifeTime = 1.0f;
    DebugLineThickness = 1.5f;

    // ����: �з��� �±�
    // AbilityTags.AddTag(FGameplayTag::RequestGameplayTag(TEXT("Ability.Ranged.Projectile"), false));
}

void UGA_Projectile::FireCurrentProfile(ARangedWeaponBase* Weapon)
{
    if (!Weapon || !bHasCachedProfile)
    {
        return;
    }

    // �� GA�ε� FireProfile�� Hitscan�̸� projectile �߻縦 ���´�.
    if (!CachedProfile.IsProjectileMode())
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] FireProfile is not Projectile mode. Weapon=%s Ability=%s"),
            *GetNameSafe(Weapon),
            *GetNameSafe(this));
        return;
    }

    // �߻� ���� �ѱ�����
    SpawnMuzzleFlash(Weapon);

    // Projectile ���� �߻� ó��
    FireProjectileOnce(Weapon);
}

void UGA_Projectile::FireProjectileOnce(ARangedWeaponBase* Weapon)
{
    if (!Weapon || !bHasCachedProfile)
    {
        return;
    }

    const FRangedProjectileConfig& Projectile = CachedProfile.Projectile;
    if (!Projectile.IsConfigured())
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] Invalid projectile config. Weapon=%s Ability=%s"),
            *GetNameSafe(Weapon),
            *GetNameSafe(this));
        return;
    }

    UWorld* World = Weapon->GetWorld();
    if (!World)
    {
        return;
    }

    FTransform SpawnTransform;
    FVector ShotDirection;
    if (!TryGetProjectileSpawnTransform(Weapon, SpawnTransform, ShotDirection))
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] TryGetProjectileSpawnTransform failed. Weapon=%s"),
            *GetNameSafe(Weapon));
        return;
    }

    float FinalDamage = 0.f;
    if (!TryGetCachedFinalDamage(Weapon, FinalDamage))
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] Failed to compute cached final damage. Weapon=%s Ability=%s"),
            *GetNameSafe(Weapon),
            *GetNameSafe(this));
        return;
    }

    const TArray<FProjectileOnHitGameplayEffectSpec> ProjectileOnHitSpecs =
        ConvertToProjectileOnHitSpecs(CachedProfile.OnHitTargetEffects);

    const FProjectileImpactFXPayload ImpactFXPayload =
        ConvertToProjectileImpactFXPayload(Weapon);

    FActorSpawnParameters Params;
    Params.Owner = GetAvatarActorFromActorInfo();
    Params.Instigator = Cast<APawn>(GetAvatarActorFromActorInfo());
    Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    AActor* SpawnedActor = World->SpawnActor<AActor>(
        Projectile.ProjectileClass,
        SpawnTransform,
        Params
    );

    if (!SpawnedActor)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] Projectile spawn failed. Class=%s Weapon=%s"),
            *GetNameSafe(Projectile.ProjectileClass),
            *GetNameSafe(Weapon));
        return;
    }

    AProjectileBase* SpawnedProjectile = Cast<AProjectileBase>(SpawnedActor);
    if (!SpawnedProjectile)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] Spawned actor is not AProjectileBase. Class=%s Actor=%s"),
            *GetNameSafe(Projectile.ProjectileClass),
            *GetNameSafe(SpawnedActor));

        SpawnedActor->Destroy();
        return;
    }

    UAbilitySystemComponent* SourceASC =
        CurrentActorInfo ? CurrentActorInfo->AbilitySystemComponent.Get() : nullptr;

    SpawnedProjectile->InitProjectileData(
        GetAvatarActorFromActorInfo(),
        SourceASC,
        BaseDamageEffectClass,
        FinalDamage,
        ProjectileOnHitSpecs,
        ImpactFXPayload
    );

    if (!ApplyProjectileLaunchSettings(SpawnedProjectile, ShotDirection))
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[GA_Projectile] Projectile launch setup failed. Projectile=%s Weapon=%s"),
            *GetNameSafe(SpawnedProjectile),
            *GetNameSafe(Weapon));

        SpawnedProjectile->Destroy();
        return;
    }

    // ���� �߻� ���� �� ��ô ������ 1�� �Ҹ�
    if (APlayerCharacter_SB* PlayerCharacter = Cast<APlayerCharacter_SB>(GetAvatarActorFromActorInfo()))
    {
        const bool bConsumed = PlayerCharacter->ConsumeSelectedThrowableAfterThrow();

        UE_LOG(LogTemp, Log,
            TEXT("[GA_Projectile] ConsumeSelectedThrowableAfterThrow -> %d"),
            bConsumed ? 1 : 0);
    }
}
#include "Weapons/MeleeWeaponBase/ClubWeapon.h"
#include "GameplayTagContainer.h"

AClubWeapon::AClubWeapon()
{
    WeaponTypeTag = FGameplayTag::RequestGameplayTag(TEXT("Weapon.Melee.Club"), false);

    // �������� Ű�� InputTag.* �� (WeaponBase.GiveAbility�� DynamicAbilityTags�� ����)
    LightAttackTag = FGameplayTag::RequestGameplayTag(TEXT("InputTag.Attack.Primary"), false);

    if (LightAttackTag.IsValid())
    {
        FWeaponAttackProfile LightProfile;
        LightProfile.Montage = nullptr; // BP���� ����
        LightProfile.MontagePlayRate = 1.0f;
        LightProfile.DamageMultiplier = 1.0f;
        LightProfile.bHitEachActorOnce = true;
        LightProfile.bHitFirstTargetOnly = true;

        AttackProfiles.Add(LightAttackTag, LightProfile);
    }
}
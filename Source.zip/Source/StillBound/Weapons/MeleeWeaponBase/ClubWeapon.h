// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapons/MeleeWeaponBase/MeleeWeaponBase.h"
#include "ClubWeapon.generated.h"

UCLASS(Blueprintable)
class STILLBOUND_API AClubWeapon : public AMeleeWeaponBase
{
    GENERATED_BODY()

public:
    AClubWeapon();

protected:
    /** �⺻���� ������ ���� �±�(�������� Ű). ��: Attack.Light */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|Melee|Club")
    FGameplayTag LightAttackTag;
};

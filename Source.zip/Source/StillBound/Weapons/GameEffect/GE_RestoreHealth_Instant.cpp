// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/GameEffect/GE_RestoreHealth_Instant.h"
#include "Character/PlayerAttributeSet.h"
#include "GameplayTagContainer.h"

UGE_RestoreHealth_Instant::UGE_RestoreHealth_Instant()
{
    DurationPolicy = EGameplayEffectDurationType::Instant;

    FGameplayModifierInfo Mod;
    Mod.Attribute = UPlayerAttributeSet::GetHealthAttribute();
    Mod.ModifierOp = EGameplayModOp::Additive;

    FSetByCallerFloat SBC;
    SBC.DataTag = FGameplayTag::RequestGameplayTag(TEXT("Data.RestoreHealth"), /*ErrorIfNotFound*/ false);

    // ���⼭ SetByCaller Ÿ������ ���õ� (MagnitudeCalculationType�� ���� ���� �ʿ� ����)
    Mod.ModifierMagnitude = FGameplayEffectModifierMagnitude(SBC);

    Modifiers.Add(Mod);
}
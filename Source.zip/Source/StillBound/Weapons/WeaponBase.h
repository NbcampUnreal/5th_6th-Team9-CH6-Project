// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameplayTagContainer.h"
#include "GameplayEffectTypes.h"
#include "GameplayAbilitySpec.h"
#include "WeaponBase.generated.h"

class UAbilitySystemComponent;
class UGameplayAbility;
class UGameplayEffect;
class USceneComponent;
class UItemBase;
class UNiagaraSystem;

USTRUCT(BlueprintType)
struct FWeaponAbilityGrant
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    TSubclassOf<UGameplayAbility> Ability = nullptr;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    int32 AbilityLevel = 1;

    /** ��: InputTag.Attack.Primary */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    FGameplayTag InputTag;
};

USTRUCT(BlueprintType)
struct FWeaponEffectGrant
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    TSubclassOf<UGameplayEffect> Effect = nullptr;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    float EffectLevel = 1.f;
};

USTRUCT(BlueprintType)
struct FWeaponHitImpactFX
{
    GENERATED_BODY()

    /** Ÿ�� ��ġ�� ������ ���̾ư��� */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|FX")
    TObjectPtr<UNiagaraSystem> NiagaraSystem = nullptr;

    /** ���� ������ */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|FX")
    FVector Scale = FVector(1.f, 1.f, 1.f);

    /** ��Ʈ ��ġ ���� �߰� ������ */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|FX")
    FVector LocationOffset = FVector::ZeroVector;

    /** ��Ʈ ��� ���� �߰� ȸ�� ������ */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|FX")
    FRotator RotationOffset = FRotator::ZeroRotator;

    /** true�� ImpactNormal �������� ȸ��, false�� �⺻ ȸ�� ��� */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|FX")
    bool bUseImpactNormalRotation = true;
};

USTRUCT()
struct FGrantedWeaponHandles
{
    GENERATED_BODY()

    UPROPERTY()
    TArray<FGameplayAbilitySpecHandle> AbilityHandles;

    UPROPERTY()
    TArray<FActiveGameplayEffectHandle> EffectHandles;

    void Reset()
    {
        AbilityHandles.Reset();
        EffectHandles.Reset();
    }
};

UCLASS(Abstract, Blueprintable)
class STILLBOUND_API AWeaponBase : public AActor
{
    GENERATED_BODY()

public:
    AWeaponBase();

    /** ����: ASC�� GA/GE �ο� + WeaponTypeTag �ۺ����� */
    UFUNCTION(BlueprintCallable, Category = "Weapon")
    virtual void Equip(AActor* NewOwner, UAbilitySystemComponent* InASC);

    /** ����: �ο��� GA/GE ȸ�� + WeaponTypeTag ���� */
    UFUNCTION(BlueprintCallable, Category = "Weapon")
    virtual void Unequip();

    /** InputTag�� �ߵ� (AbilitySpec.DynamicAbilityTags ����) */
    UFUNCTION(BlueprintCallable, Category = "Weapon")
    bool ActivateByInputTag(FGameplayTag InputTag);

    /** ���� ��Ʈ(�ʿ��ϸ� Attach/������ ĳ���Ͱ� ó��) */
    UFUNCTION(BlueprintPure, Category = "Weapon")
    USceneComponent* GetWeaponRoot() const { return Root; }

    /** ������(�Ǵ� DT)���� ���� ���� */
    UFUNCTION(BlueprintCallable, Category = "Weapon|Init")
    virtual void InitFromItem(const UItemBase* Item);

    UFUNCTION(BlueprintPure, Category = "Weapon|Stats")
    float GetWeaponDamage() const { return WeaponDamage; }

    UFUNCTION(BlueprintPure, Category = "Weapon|Tags")
    FGameplayTag GetWeaponTypeTag() const { return WeaponTypeTag; }

    UFUNCTION(BlueprintPure, Category = "Weapon|FX")
    const FWeaponHitImpactFX& GetHitImpactFX() const { return HitImpactFX; }

    UFUNCTION(BlueprintPure, Category = "Weapon|Equip")
    FName GetEquipSocketName() const { return EquipSocketName; }

protected:
    /** DT/�����ۿ��� ���� ���� ���ݷ� ĳ��(SoT: DT) */
    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "Weapon|Stats")
    float WeaponDamage = 0.f;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
    TObjectPtr<USceneComponent> Root;

    /** ��: Weapon_R, Weapon_L / ��������� ĳ���� �⺻ ���� ��� */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|Equip")
    FName EquipSocketName = NAME_None;

    /** ��: Weapon.Melee.Club, Weapon.Ranged.Rifle */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|Tags")
    FGameplayTag WeaponTypeTag;

    /** Equip �� ASC�� GiveAbility */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    TArray<FWeaponAbilityGrant> GrantedAbilities;

    /** Equip �� ASC�� ApplyGE(Self) */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|GAS")
    TArray<FWeaponEffectGrant> GrantedEffects;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon|FX")
    FWeaponHitImpactFX HitImpactFX;
protected:
    virtual void GrantToASC(UAbilitySystemComponent* ASC);
    virtual void RevokeFromASC(UAbilitySystemComponent* ASC);

    void ApplyWeaponTypeTag(UAbilitySystemComponent* ASC, bool bAdd) const;

protected:
    UPROPERTY()
    bool bEquipped = false;

    UPROPERTY()
    TWeakObjectPtr<UAbilitySystemComponent> EquippedASC;

    UPROPERTY()
    TWeakObjectPtr<AActor> EquippedOwner;

    UPROPERTY()
    FGrantedWeaponHandles GrantedHandles;
};
// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "GameplayTagContainer.h"
#include "AN_SendRangedFireEvent.generated.h"


UCLASS(meta = (DisplayName = "Ranged Fire Event"))
class STILLBOUND_API UAN_SendRangedFireEvent : public UAnimNotify
{
    GENERATED_BODY()

public:
    UAN_SendRangedFireEvent();

    virtual FString GetNotifyName_Implementation() const override;

    // //�߰�: ��Ÿ�� Ư�� �����ӿ��� Event.Ranged.Fire ����
    virtual void Notify(
        USkeletalMeshComponent* MeshComp,
        UAnimSequenceBase* Animation,
        const FAnimNotifyEventReference& EventReference
    ) override;

protected:
    // //�߰�: ���� Gameplay Event �±�
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Weapon|Ranged")
    FGameplayTag EventTag;

    // //�߰�: ASC ���� ���͸� ������ �ʰ� ������ġ
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Weapon|Ranged")
    bool bRequireAbilitySystem = true;
};